| Footer |
|---|
| [Facebook](https://www.facebook.com/docgovtnz) [Blog](https://blog.doc.govt.nz/) [Instagram](https://www.instagram.com/docgovtnz/) [Youtube](https://www.youtube.com/docgovtnz) [Other channels](/news/social-media/) |
| ![New Zealand Government](./images/nz-govt-logo.svg) |
| [Careers](/careers/) [News & events](/news/) [About us](/about-us/) [Contact](/footer-links/contact-us/) |
| [Copyright](/footer-links/copyright/) [About this site](/footer-links/about-this-site/) [Privacy & security](/footer-links/privacy-and-security/) [OIA requests](/footer-links/contact-us/making-an-official-information-act-request/) |
